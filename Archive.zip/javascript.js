

function validar() {
    var nombre = document.getElementById("nombre").value;
    var apellidos = document.getElementById("apellidos").value;
    var correo = document.getElementById("correo").value;
    var usuario = document.getElementById("usuario").value;
    var pass = document.getElementById("pass").value;
    var telefono = document.getElementById("telefono").value;
    const letters = /^[A-Za-z]+$/;
    const mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
//seguridad JS LOL
    if (nombre.match(letters)) {
        var letras = "E";
    }
    else {
        var letras = 0;

    }

    if (nombre.match(mailformat)) {
        var femail = 1;
    }
    else {
        var femail = "E";

    }


    if ((nombre === "") && (apellidos === "") && (correo === "") && (usuario === "") && (pass === "") && (telefono === "")) {
        alert("todos los campos son obligatorios, completar!");
        return false;
    }
    else if (letras ===  "E") {
        alert("solo debe tener letras el nombre");
        return false;
    } else if (nombre.length > 30) {
        alert("El nombre es muy largo");
        return false;
    } else if (apellidos.length > 80) {
        alert("El apellido es muy largo");
        return false;
    } else if (correo.length > 100) {
        alert("El correo electrónico es muy largo");
    } else if (femail ===  "E") {
        alert("El correo electrónico es muy largo");
        return false;
    } else if (usuario.length > 20) {
        alert("El usuario es muy largo");
        return false;
    } else if (telefono.length > 10) {
        alert("El teléfono es muy largo");
        return false;
    } else if (isNaN(telefono)) {
        alert("Que el campo teléfono acepte solo datos numéricos.");
        return false;
    } else {
        alert(`Saludos humano ${nombre} ${apellidos}`);
        var resultado = `Registrado: ${nombre} ${apellidos}`;
        document.getElementById("resultado").innerHTML = resultado;
        return false;
    }
    
}
